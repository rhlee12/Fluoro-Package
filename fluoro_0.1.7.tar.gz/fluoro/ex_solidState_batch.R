### batch ss correct
out=solid.combo.correct(eem.dir = "../180316/", combo.file = "../F4SPF_LOG SHEET_BBWM_180426.xlsx")
eem.grid.plot(corr.dir = out$corr.dir, combo.file = "../F4SPF_LOG SHEET_BBWM_180426.xlsx")


out=solid.combo.correct(eem.dir = "../180516/", combo.file = "../F4SPF_LOG SHEET_BBWM_180516.xlsx")
eem.grid.plot(corr.dir = out$corr.dir, combo.file = "../F4SPF_LOG SHEET_BBWM_180516.xlsx")
