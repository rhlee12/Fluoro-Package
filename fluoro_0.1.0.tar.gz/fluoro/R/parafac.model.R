#' @title Perform PARAFAC Modeling on Corrected EEMs
#'
#' @author
#'
#' @details
#'
#' @param \code{} -
#'
#' @return
#'
#' @example
#'
#' #export when finished
#'

parafac.model=function(expanded.eem, num.factors){
length(expanded.eem)
  stats::reshape()
}
